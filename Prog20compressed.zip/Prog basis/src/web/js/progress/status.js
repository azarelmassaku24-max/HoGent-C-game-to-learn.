/**
 * Voortgangsstatus van lessen, levels en vaardigheden.
 *
 * Belangrijk: deze module METEN alleen wat de leerling al deed. Ze bepaalt nooit of iets
 * toegankelijk is — elk level, elke les, elke stap en elke opdracht is altijd open.
 * Statussen: 'completed' (voltooid) | 'in-progress' (bezig) | 'not-started' (nog niet gestart).
 */

// Lestypes die meetellen voor de voortgang van een level (in volgorde).
export const CORE_KINDS = new Set(['lesson', 'boss', 'project']);

export const STATUS_LABEL = { completed: 'Voltooid', 'in-progress': 'Bezig', 'not-started': 'Nog niet gestart' };
export const STATUS_ICON = { completed: 'checkCircle', 'in-progress': 'play', 'not-started': 'circle' };

export function isExercisePassed(p, id) {
  return p.exercises[id]?.status === 'passed';
}

/** Een les is voltooid als de meesterschapsopdracht (of alle opdrachten) geslaagd zijn. */
export function isLessonComplete(p, lesson) {
  if (p.lessons[lesson.id]?.completedAt) return true;
  const exercises = lesson.exercises || [];
  if (exercises.length === 0) return false;
  if (lesson.kind === 'lesson') {
    const mastery = exercises.filter((e) => e.role === 'meesterschap');
    const required = mastery.length ? mastery : exercises;
    return required.every((e) => isExercisePassed(p, e.id));
  }
  if (lesson.kind === 'boss' || lesson.kind === 'project') return exercises.every((e) => isExercisePassed(p, e.id));
  return false;
}

/** Heeft de leerling al iets gedaan in deze les (geopend, voorspeld, een opdracht geprobeerd)? */
export function isLessonStarted(p, lesson) {
  if (p.lessons[lesson.id]?.startedAt) return true;
  return (lesson.exercises || []).some((e) => (p.exercises[e.id]?.attempts || 0) > 0 || isExercisePassed(p, e.id));
}

/** completed | in-progress | not-started — een voortgangsindicator, nooit een toegangsregel. */
export function lessonStatus(p, lesson) {
  if (isLessonComplete(p, lesson)) return 'completed';
  return isLessonStarted(p, lesson) ? 'in-progress' : 'not-started';
}

export function levelCoreLessons(level) {
  return level.lessons.filter((l) => CORE_KINDS.has(l.kind));
}

export function isLevelComplete(p, level) {
  const core = levelCoreLessons(level);
  return core.length > 0 && core.every((l) => isLessonComplete(p, l));
}

export function levelProgress(p, level) {
  const core = levelCoreLessons(level);
  const done = core.filter((l) => isLessonComplete(p, l)).length;
  return { done, total: core.length, pct: core.length ? Math.round((done / core.length) * 100) : 0 };
}

/** completed | in-progress | not-started voor een volledig level. */
export function levelStatus(p, level) {
  if (isLevelComplete(p, level)) return 'completed';
  return level.lessons.some((l) => isLessonStarted(p, l)) ? 'in-progress' : 'not-started';
}

/** Beheersing van een vaardigheid uit de skill tree: mastered | learning | not-started. */
export function skillStatus(p, skill) {
  const s = p.skills[skill.id];
  if ((s?.mastery || 0) >= 0.8 && (s?.passes || 0) >= 2) return 'mastered';
  if (s && ((s.attempts || 0) > 0 || (s.passes || 0) > 0)) return 'learning';
  return 'not-started';
}
