import { html, useEffect, useState } from '../lib/preact.js';
import { Icon } from '../components/Icon.js';
import { Badge, Progress, Segmented, Empty } from '../components/ui.js';
import { useProgress } from '../hooks/useProgress.js';
import { curriculumService } from '../services/curriculumService.js';
import { lessonStatus, levelStatus, levelProgress, STATUS_LABEL, STATUS_ICON } from '../progress/status.js';
import { nextMission } from '../progress/recommend.js';

const KIND_ICON = { lesson: 'book', boss: 'sword', project: 'users', challenges: 'target', verdieping: 'sparkles' };
const LEVEL_BADGE_TONE = { completed: 'success', 'in-progress': 'accent', 'not-started': undefined };

/** Alle levels en lessen. Alles is vrij toegankelijk; de statussen tonen enkel je voortgang. */
export function Academy({ focus }) {
  const p = useProgress();
  const c = curriculumService.get();
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(() => {
    if (focus && c.levelMap.has(focus)) return new Set([focus]);
    const mission = nextMission(p, c);
    return new Set([mission?.lesson.levelId || c.levels[0]?.id].filter(Boolean));
  });
  useEffect(() => {
    if (!focus) return;
    setOpen((o) => new Set([...o, focus]));
    setTimeout(() => document.getElementById('lvl-' + focus)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  }, [focus]);

  const levels = c.levels.filter((l) => filter === 'all' || (filter === 'regulier' ? l.kind === 'level' : l.kind !== 'level'));
  const toggle = (id) => { const s = new Set(open); s.has(id) ? s.delete(id) : s.add(id); setOpen(s); };
  const jump = (id) => {
    if (filter !== 'all') setFilter('all');
    setOpen((o) => new Set([...o, id]));
    setTimeout(() => document.getElementById('lvl-' + id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  };

  return html`<div class="page">
    <div class="page-header">
      <div>
        <div class="eyebrow">Academy</div>
        <h1>Alle modules en lessen</h1>
        <p>${c.levels.length} levels · ${c.orderedLessons.length} lessen · ${c.exercises.size} programmeeropdrachten. Alles is vrij toegankelijk: kies zelf waar je begint. De volgorde en terminologie volgen je cursus “Programmeren Basis”.</p>
      </div>
      <${Segmented} value=${filter} onChange=${setFilter} options=${[{ value: 'all', label: 'Alles' }, { value: 'regulier', label: 'Leertraject' }, { value: 'extra', label: 'Project & verdieping' }]} />
    </div>
    ${c.problems?.length ? html`<div class="callout warn"><${Icon} name="alert" /><div><strong>Let op:</strong> ${c.problems.length} probleem/problemen in de leerinhoud. Voer <code>dotnet run -- verify</code> uit voor details.</div></div>` : null}

    <nav class="level-jump" aria-label="Spring naar een level">
      ${c.levels.map((level) => {
        const st = levelStatus(p, level);
        return html`<button type="button" class=${`level-chip ${st}`} style=${{ '--level-color': level.color }} onClick=${() => jump(level.id)}
          title=${`Level ${level.number}: ${level.title} — ${STATUS_LABEL[st]}`} aria-label=${`Level ${level.number}: ${level.title} (${STATUS_LABEL[st]})`}>
          ${st === 'completed' ? html`<${Icon} name="check" size="13" />` : null}${level.number}
        </button>`;
      })}
    </nav>
    <div class="status-legend small muted" aria-hidden="true">
      ${['completed', 'in-progress', 'not-started'].map((s) => html`<span class=${`legend-item ${s}`}><${Icon} name=${STATUS_ICON[s]} size="14" /> ${STATUS_LABEL[s]}</span>`)}
    </div>

    <div class="stack">
      ${levels.map((level) => {
        const prog = levelProgress(p, level);
        const st = levelStatus(p, level);
        const isOpen = open.has(level.id);
        return html`<section class=${`level-card ${st}`} id=${'lvl-' + level.id} style=${{ '--level-color': level.color }}>
          <button type="button" class="level-head" onClick=${() => toggle(level.id)} aria-expanded=${isOpen} aria-controls=${'lvl-body-' + level.id}>
            <div class="level-num">${level.kind === 'level' ? level.number : html`<${Icon} name=${level.kind === 'project' ? 'users' : 'sparkles'} />`}</div>
            <div class="grow">
              <div class="row wrap" style="gap:8px">
                <h2 class="level-title">${level.kind !== 'level' ? `${level.number}. ` : ''}${level.title}</h2>
                ${level.kind === 'verdieping' ? html`<${Badge} tone="info">Verdieping</${Badge}>` : level.kind === 'project' ? html`<${Badge} tone="success">Doorlopend project</${Badge}>` : null}
                ${level.lessons.length ? html`<${Badge} tone=${LEVEL_BADGE_TONE[st]} icon=${STATUS_ICON[st]}>${STATUS_LABEL[st]}</${Badge}>` : html`<${Badge} icon="clock">Inhoud volgt</${Badge}>`}
              </div>
              <div class="muted small">${level.subtitle}${level.source ? ' · ' + level.source : ''}</div>
            </div>
            <div class="level-meta hide-sm">
              <div class="small"><strong>${prog.done}</strong>/${prog.total}</div>
              <div style="width:110px"><${Progress} value=${prog.pct} tone=${prog.pct === 100 ? 'success' : ''} size="thin" /></div>
            </div>
            <${Icon} name=${isOpen ? 'chevronDown' : 'chevronRight'} />
          </button>
          ${isOpen ? html`<div class="level-body fade-in" id=${'lvl-body-' + level.id}>
            ${level.description ? html`<p class="muted">${level.description}</p>` : null}
            ${level.note ? html`<div class="callout info"><${Icon} name="info" /><div>${level.note}</div></div>` : null}
            ${level.lessons.length ? html`<ol class="lesson-list">
              ${level.lessons.map((lesson) => {
                const ls = lessonStatus(p, lesson);
                const passedEx = lesson.exercises.filter((e) => p.exercises[e.id]?.status === 'passed').length;
                return html`<li class=${`lesson-row ${ls} kind-${lesson.kind}`}>
                  <a href=${`#/les/${lesson.id}`}>
                    <span class="lesson-status" title=${STATUS_LABEL[ls]}><${Icon} name=${lesson.kind !== 'lesson' && ls !== 'completed' ? KIND_ICON[lesson.kind] : STATUS_ICON[ls]} size="17" /></span>
                    <span class="grow">
                      <span class="lesson-name">${lesson.kind === 'boss' ? 'Boss: ' : ''}${lesson.title} <span class=${`status-text ${ls}`}>${STATUS_LABEL[ls]}</span></span>
                      <span class="lesson-sub">${lesson.summary}</span>
                    </span>
                    <span class="lesson-tags hide-sm">
                      ${lesson.source ? html`<span class="source-tag">${lesson.source}</span>` : null}
                      <span class="faint xs">${passedEx}/${lesson.exercises.length} opdrachten</span>
                    </span>
                  </a>
                </li>`;
              })}
            </ol>` : html`<${Empty} icon="clock" title="Nog geen lessen in dit level">De leerinhoud voor ${level.source || 'dit deel'} is nog niet toegevoegd. Zodra de lessen in de curriculummap staan, verschijnen ze hier automatisch.</${Empty}>`}
          </div>` : null}
        </section>`;
      })}
    </div>
  </div>`;
}
