import { html, useEffect, useState } from '../lib/preact.js';
import { Icon } from '../components/Icon.js';
import { Badge, Button, Callout, ErrorBox, LinkButton, Progress, Spinner, Modal } from '../components/ui.js';
import { Markdown } from '../components/Markdown.js';
import { PredictQuestion } from '../features/lesson/PredictQuestion.js';
import { Workbench } from '../features/lab/Workbench.js';
import { FeedbackView } from '../features/lab/FeedbackPanels.js';
import { curriculumService } from '../services/curriculumService.js';
import { codeService } from '../services/codeService.js';
import { useProgress } from '../hooks/useProgress.js';
import { engine } from '../progress/engine.js';
import { CORE_KINDS } from '../progress/status.js';
import { practiceFor } from '../progress/recommend.js';

const STEPS = [
  { id: 'begrijpen', label: 'Begrijpen', icon: 'book' },
  { id: 'voorbeeld', label: 'Voorbeeld', icon: 'code' },
  { id: 'voorspellen', label: 'Voorspellen', icon: 'eye' },
  { id: 'programmeren', label: 'Programmeren', icon: 'terminal' },
  { id: 'controleren', label: 'Controleren', icon: 'checkCircle' },
  { id: 'meesterschap', label: 'Meesterschap', icon: 'crown' },
];

// Laatste beoordelingen in deze sessie (voor de stap 'Controleren').
const lastResults = new Map();

/**
 * Een les. Elke les en elke leerstap is altijd toegankelijk: voortgang wordt bijgehouden
 * en getoond, maar bepaalt nooit wat je mag openen. #/les/<id>?stap=6 opent meteen stap 6.
 */
export function LessonPage({ id, step: stepParam }) {
  const c = curriculumService.get();
  const summary = c.lessons.get(id);
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    setDetail(null);
    setError(null);
    curriculumService.lesson(id).then(setDetail, setError);
  }, [id]);

  if (!summary) return html`<div class="page"><div class="message-screen card">
    <div class="icon-tile muted" style="width:56px;height:56px"><${Icon} name="alert" size="26" /></div>
    <h2>Les niet gevonden</h2>
    <p class="muted">De les “${id}” bestaat niet (meer). Kies een andere les in de Academy.</p>
    <${LinkButton} href="#/academy" icon="graduation">Naar de Academy</${LinkButton}>
  </div></div>`;
  if (error) return html`<div class="page"><${ErrorBox} error=${error} retry=${() => { setError(null); curriculumService.lesson(id).then(setDetail, setError); }} /></div>`;
  // Wacht tot de inhoud van DEZE les geladen is (niet nog die van de vorige les).
  if (!detail || detail.summary?.id !== id) return html`<div class="page"><${Spinner} label="Les laden…" /></div>`;

  if (summary.kind === 'boss' || summary.kind === 'project') return html`<${PhasedLesson} key=${id} lesson=${summary} detail=${detail} />`;
  if (summary.kind === 'challenges') return html`<${ChallengeSet} key=${id} lesson=${summary} detail=${detail} />`;
  return html`<${LessonPlayer} key=${id} lesson=${summary} detail=${detail} stepParam=${stepParam} />`;
}

function LessonHeader({ lesson, children }) {
  return html`<div class="lesson-header">
    <div class="lesson-header-inner">
      <a class="back-link" href=${`#/academy/${lesson.levelId}`}><${Icon} name="arrowLeft" size="15" /> Level ${lesson.level.number}: ${lesson.level.title}</a>
      <div class="row between wrap">
        <div>
          <h1 class="lesson-title">${lesson.kind === 'verdieping' ? html`<span class="badge badge-info" style="vertical-align:middle;margin-right:8px">Verdieping</span>` : null}${lesson.title}</h1>
          <div class="row wrap small muted" style="gap:10px">
            ${lesson.source ? html`<span class="source-tag"><${Icon} name="book" size="13" /> ${lesson.source}</span>` : null}
            <span><${Icon} name="clock" size="13" /> ±${lesson.minutes} min</span>
            ${lesson.skills.map((s) => html`<${Badge}>${curriculumService.get().skillMap.get(s)?.title || s}</${Badge}>`)}
          </div>
        </div>
      </div>
      ${children}
    </div>
  </div>`;
}

const LAST_STEP = STEPS.length - 1;

/** Stapnummer uit de URL (?stap=1..6) → index 0..5, of null. */
function parseStepParam(value) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) && n >= 1 && n <= STEPS.length ? n - 1 : null;
}

function LessonPlayer({ lesson, detail, stepParam }) {
  const p = useProgress();
  const lp = p.lessons[lesson.id] || {};
  const practice = lesson.exercises.filter((e) => e.role === 'oefenen');
  const mastery = lesson.exercises.filter((e) => e.role === 'meesterschap');
  const [step, setStep] = useState(() => parseStepParam(stepParam) ?? Math.min(Math.max(lp.step || 0, 0), LAST_STEP));
  const [practiceIndex, setPracticeIndex] = useState(() => Math.max(0, practice.findIndex((e) => p.exercises[e.id]?.status !== 'passed')));
  const completed = !!lp.completedAt;

  useEffect(() => { engine.startLesson(lesson.id); }, [lesson.id]);
  useEffect(() => { const s = parseStepParam(stepParam); if (s !== null) setStep(s); }, [stepParam]);
  useEffect(() => {
    engine.setStep(lesson.id, step);
    // De code review bekijken = de stap 'Controleren' is gedaan.
    if (step === 4) engine.markReviewed(lesson.id);
  }, [step]);

  // Voortgang per stap: enkel om ✓ te tonen. Elke stap blijft altijd aanklikbaar.
  const predictionsDone = detail.predictions.every((q) => lp.predictions?.[q.id]?.correct || lp.predictions?.[q.id]?.revealed);
  const practiceDone = practice.every((e) => p.exercises[e.id]?.status === 'passed');
  const masteryDone = mastery.length > 0 && mastery.every((e) => p.exercises[e.id]?.status === 'passed');
  // Bekeken = de stap stond ooit open. Oudere voortgang (zonder 'visited') valt terug op maxStep.
  const visited = (i) => (Array.isArray(lp.visited) ? lp.visited.includes(i) : lp.maxStep > 0 && i <= lp.maxStep);
  const stepDone = [
    visited(0),
    visited(1),
    detail.predictions.length ? predictionsDone : visited(2),
    practice.length ? practiceDone : visited(3),
    !!lp.reviewed || (!practice.length && visited(4)),
    masteryDone,
  ];

  const goTo = (i) => {
    setStep(Math.min(LAST_STEP, Math.max(0, i)));
    document.querySelector('.lesson-header')?.scrollIntoView({ block: 'start' });
  };
  const content = {
    0: html`<${Markdown} text=${detail.understand} />`,
    1: html`<${Markdown} text=${detail.example || '_Geen voorbeeld._'} />`,
    2: html`<${PredictStep} lesson=${lesson} detail=${detail} />`,
    3: practice.length ? html`<${PracticeStep} lesson=${lesson} exercises=${practice} index=${practiceIndex} setIndex=${setPracticeIndex} />` : html`<p class="muted">Deze les heeft geen aparte oefenopdracht.</p>`,
    4: html`<${ReviewStep} lesson=${lesson} exercises=${practice} />`,
    5: mastery.length ? html`<${MasteryStep} lesson=${lesson} exercise=${mastery[0]} />` : html`<p class="muted">Geen meesterschapsopdracht.</p>`,
  }[step];

  const isWorkbenchStep = (step === 3 && practice.length) || (step === 5 && mastery.length);
  const nextLesson = findNext(lesson);
  // Niet-blokkerende tip als je verdergaat zonder de huidige stap af te ronden.
  const openNote = step === 2 && detail.predictions.length && !predictionsDone ? 'Nog niet alle vragen beantwoord — je kan er later naar terugkeren.'
    : step === 3 && practice.length && !practiceDone ? 'De oefening is nog niet opgelost — je kan er later naar terugkeren.'
    : '';

  return html`<div class="lesson">
    <${LessonHeader} lesson=${lesson}>
      <ol class="stepper" aria-label="Leerstappen">
        ${STEPS.map((s, i) => {
          const done = stepDone[i] && i !== step;
          return html`<li class=${`step ${i === step ? 'current' : ''} ${stepDone[i] ? 'done' : ''}`}>
          <button type="button" onClick=${() => goTo(i)} aria-current=${i === step ? 'step' : undefined}
            aria-label=${`Stap ${i + 1}: ${s.label}${stepDone[i] ? ' (voltooid)' : ''}`}>
            <span class="step-icon"><${Icon} name=${done ? 'check' : s.icon} size="15" /></span>
            <span class="step-label"><span class="step-num">Stap ${i + 1}</span>${s.label}</span>
          </button>
        </li>`;
        })}
      </ol>
    </${LessonHeader}>

    ${completed ? html`<div class="lesson-complete-bar"><${Icon} name="trophy" size="16" /> Les voltooid!
      ${nextLesson ? html`<${LinkButton} size="sm" variant="primary" href=${`#/les/${nextLesson.id}`} iconRight="arrowRight">Volgende: ${nextLesson.title}</${LinkButton}>` : null}</div>` : null}

    <div class=${isWorkbenchStep ? 'lesson-body wide' : 'lesson-body'}>
      ${step === 0 && lesson.supplement ? html`<${Callout} tone="info" icon="info" title="Over deze uitleg:">${lesson.supplement}</${Callout}>` : null}
      ${content}
      <div class="lesson-nav">
        <${Button} variant="ghost" icon="arrowLeft" disabled=${step === 0} onClick=${() => goTo(step - 1)}>Vorige</${Button}>
        ${openNote ? html`<span class="faint small lesson-nav-note">${openNote}</span>` : null}
        ${step < LAST_STEP
          ? html`<${Button} variant="primary" iconRight="arrowRight" onClick=${() => goTo(step + 1)}>Verder: ${STEPS[step + 1].label}</${Button}>`
          : html`<div class="row wrap">
              <${LinkButton} variant="ghost" href=${`#/academy/${lesson.levelId}`} icon="graduation">Terug naar het level</${LinkButton}>
              ${nextLesson ? html`<${LinkButton} variant=${masteryDone ? 'primary' : undefined} href=${`#/les/${nextLesson.id}`} iconRight="arrowRight">Volgende les: ${nextLesson.title}</${LinkButton}>` : null}
            </div>`}
      </div>
    </div>
  </div>`;
}

/** De volgende les in de volgorde van de cursus (over levels heen), of null aan het einde. */
function findNext(lesson) {
  const c = curriculumService.get();
  const list = c.orderedLessons.filter((l) => CORE_KINDS.has(l.kind));
  const i = list.findIndex((l) => l.id === lesson.id);
  return i >= 0 ? list[i + 1] || null : null;
}

function PredictStep({ lesson, detail }) {
  const p = useProgress();
  if (!detail.predictions.length) return html`<p class="muted">Geen voorspelvragen in deze les.</p>`;
  const lp = p.lessons[lesson.id] || {};
  const done = detail.predictions.filter((q) => lp.predictions?.[q.id]?.correct || lp.predictions?.[q.id]?.revealed).length;
  return html`<div class="stack">
    <div class="predict-intro">
      <h2>Voorspel eerst, dan pas uitvoeren</h2>
      <p class="muted">Programmeurs lezen code en voorspellen wat ze doet. Beantwoord elke vraag <strong>voordat</strong> je de uitleg ziet. Het juiste antwoord bij vragen over output wordt bepaald door de code echt uit te voeren.</p>
      <${Progress} value=${(done / detail.predictions.length) * 100} label="Beantwoorde vragen" />
    </div>
    ${detail.predictions.map((q, i) => html`<${PredictQuestion} key=${q.id} lesson=${lesson} q=${q} index=${i} total=${detail.predictions.length} />`)}
  </div>`;
}

function PracticeStep({ lesson, exercises, index, setIndex }) {
  const p = useProgress();
  const c = curriculumService.get();
  const ex = exercises[index] || exercises[0];
  const st = p.exercises[ex.id] || {};
  const struggling = (st.attempts || 0) >= 3 && st.status !== 'passed';
  const extra = struggling ? practiceFor(p, c, ex.skills[0], 3).filter((e) => e.id !== ex.id && e.lesson.id !== lesson.id) : [];
  return html`<div class="stack">
    ${exercises.length > 1 ? html`<div class="row wrap">
      ${exercises.map((e, i) => html`<button class=${`chip ${i === index ? 'active' : ''}`} onClick=${() => setIndex(i)}>
        ${p.exercises[e.id]?.status === 'passed' ? html`<${Icon} name="check" size="13" />` : html`<span class="faint">${i + 1}</span>`} ${e.title}</button>`)}
    </div>` : null}
    ${struggling ? html`<${Callout} tone="tip" title="Dit lijkt lastig — dat is normaal!">
      Je probeerde dit al ${st.attempts} keer. Bekijk de feedback in het tabblad <strong>Feedback</strong>, gebruik een hint of de <strong>Debugger</strong>.
      ${extra.length ? html`<div style="margin-top:6px">Of oefen eerst met: ${extra.map((e, i) => html`${i ? ', ' : ''}<a href=${`#/lab/${e.id}`}>${e.title}</a>`)}</div>` : null}
    </${Callout}>` : null}
    <${Workbench} exerciseId=${ex.id} embedded onGraded=${(res) => {
      lastResults.set(ex.id, res);
      if (res.passed) {
        const nextIdx = exercises.findIndex((e, i) => i > index && p.exercises[e.id]?.status !== 'passed');
        if (nextIdx > 0) setTimeout(() => setIndex(nextIdx), 1200);
      }
    }} />
  </div>`;
}

function ReviewStep({ lesson, exercises }) {
  const p = useProgress();
  const [results, setResults] = useState(() => Object.fromEntries(exercises.map((e) => [e.id, lastResults.get(e.id)])));
  const [busy, setBusy] = useState(null);
  const [solution, setSolution] = useState(null);

  async function regrade(ex) {
    const files = p.exercises[ex.id]?.files;
    if (!files) return;
    setBusy(ex.id);
    try {
      const res = await codeService.grade(ex.id, files);
      lastResults.set(ex.id, res);
      engine.recordGrade(ex, res, files);
      setResults((r) => ({ ...r, [ex.id]: res }));
    } finally { setBusy(null); }
  }

  if (!exercises.length) return html`<p class="muted">Geen oefeningen om te controleren.</p>`;
  return html`<div class="stack">
    <div>
      <h2>Controleer je oplossing kritisch</h2>
      <p class="muted">Werkende code is pas het begin. Bekijk hieronder de code review: zijn er nog structuurproblemen, onnodige code of verbeterpunten? Een verbeterde versie zonder opmerkingen levert extra XP op.</p>
    </div>
    ${exercises.map((ex) => {
      const res = results[ex.id];
      const st = p.exercises[ex.id] || {};
      return html`<div class="card">
        <div class="card-header">
          <h3 class="card-title"><${Icon} name="code" />${ex.title}</h3>
          <div class="row">
            <${Button} size="sm" icon="rotate" loading=${busy === ex.id} onClick=${() => regrade(ex)}>${res ? 'Opnieuw beoordelen' : 'Beoordeling tonen'}</${Button}>
            ${st.status === 'passed' ? html`<${Button} size="sm" icon="eye" onClick=${async () => setSolution(await curriculumService.solution(ex.id))}>Vergelijk met modeloplossing</${Button}>` : null}
          </div>
        </div>
        ${res ? html`<${FeedbackView} result=${res} />` : html`<p class="muted small">${st.lastSummary ? `Laatste resultaat: ${st.lastSummary.passed ? 'geslaagd' : 'niet geslaagd'}, ${st.lastSummary.quality} verbeterpunt(en).` : 'Nog geen beoordeling.'}</p>`}
      </div>`;
    })}
    <div class="card">
      <h3 class="card-title"><${Icon} name="brain" /> Reflectie</h3>
      <ul class="reflect">
        <li>Kan je voor elke regel van je oplossing uitleggen wat hij doet?</li>
        <li>Wat gebeurt er als de gebruiker onverwachte invoer geeft (0, een negatief getal, tekst)?</li>
        <li>Zijn je variabelennamen duidelijk voor iemand anders (camelCasing, betekenisvol)?</li>
        <li>Staat er code dubbel die je kan vereenvoudigen?</li>
      </ul>
    </div>
    ${solution ? html`<${Modal} title="Modeloplossing ter vergelijking" wide onClose=${() => setSolution(null)}>
      <${Callout} tone="info">Je loste deze opdracht al op. Vergelijk: welke keuzes maakte jij anders? Er zijn vaak meerdere goede oplossingen.</${Callout}>
      ${solution.files.map((f) => html`<${Markdown} text=${'```csharp titel="' + f.path + '"\n' + f.content.trimEnd() + '\n```'} />`)}
      ${solution.explanation ? html`<${Markdown} text=${solution.explanation} />` : null}
    </${Modal}>` : null}
  </div>`;
}

function MasteryStep({ lesson, exercise }) {
  const p = useProgress();
  const passed = p.exercises[exercise.id]?.status === 'passed';
  return html`<div class="stack">
    <div class="mastery-intro">
      <div class="icon-tile warning"><${Icon} name="crown" /></div>
      <div>
        <h2>Meesterschap</h2>
        <p class="muted">Een moeilijkere opdracht waarin je het nieuwe concept combineert met eerdere leerstof. Slaag je, dan is de les voltooid en verdien je extra XP.</p>
      </div>
      ${passed ? html`<${Badge} tone="success" icon="check">Behaald</${Badge}>` : null}
    </div>
    <${Workbench} exerciseId=${exercise.id} embedded onGraded=${(res) => lastResults.set(exercise.id, res)} />
  </div>`;
}

/** Boss fights en het personenproject: meerdere fases na elkaar. */
function PhasedLesson({ lesson, detail }) {
  const p = useProgress();
  const phases = lesson.exercises;
  const firstOpen = phases.findIndex((e) => p.exercises[e.id]?.status !== 'passed');
  const [index, setIndex] = useState(firstOpen < 0 ? 0 : firstOpen);
  const [briefing, setBriefing] = useState(() => !p.lessons[lesson.id]?.startedAt);
  const passedCount = phases.filter((e) => p.exercises[e.id]?.status === 'passed').length;
  const hp = Math.round(100 - (passedCount / phases.length) * 100);
  const isBoss = lesson.kind === 'boss';
  useEffect(() => { engine.startLesson(lesson.id); }, [lesson.id]);
  const current = phases[index];
  const prevFiles = index > 0 ? p.exercises[phases[index - 1].id]?.files : null;
  const [seed, setSeed] = useState(0);

  return html`<div class="lesson">
    <${LessonHeader} lesson=${lesson}>
      <div class=${`boss-bar ${isBoss ? '' : 'project'}`}>
        <div class="boss-avatar"><${Icon} name=${isBoss ? 'skull' : 'users'} size="26" /></div>
        <div class="grow">
          <div class="row between"><strong>${isBoss ? 'Boss HP' : 'Projectvoortgang'}</strong><span class="mono small">${isBoss ? `${hp}%` : `${passedCount}/${phases.length} fases`}</span></div>
          <div class=${`progress thick ${isBoss ? 'danger' : 'success'}`}><span style=${{ width: (isBoss ? hp : (passedCount / phases.length) * 100) + '%' }}></span></div>
        </div>
        <${Button} size="sm" variant="ghost" icon="book" onClick=${() => setBriefing(true)}>${isBoss ? 'Briefing' : 'Projectomschrijving'}</${Button}>
      </div>
      <div class="phase-tabs">
        ${phases.map((e, i) => html`<button type="button" class=${`phase ${i === index ? 'active' : ''} ${p.exercises[e.id]?.status === 'passed' ? 'done' : ''}`} onClick=${() => setIndex(i)} aria-current=${i === index ? 'step' : undefined}>
          <${Icon} name=${p.exercises[e.id]?.status === 'passed' ? 'check' : isBoss ? 'sword' : 'code'} size="14" />
          <span>${e.phase || `Fase ${i + 1}`}</span>
        </button>`)}
      </div>
    </${LessonHeader}>
    <div class="lesson-body wide">
      ${prevFiles && !p.exercises[current.id]?.files ? html`<${Callout} tone="tip" title="Verder bouwen?">
        Je kan deze fase starten vanaf je eigen code van de vorige fase.
        <${Button} size="sm" icon="git" onClick=${() => { engine.saveDraft(current.id, prevFiles); setSeed(seed + 1); }}>Neem mijn code van de vorige fase over</${Button}>
      </${Callout}>` : null}
      <${Workbench} key=${current.id + seed} exerciseId=${current.id} embedded onGraded=${(res) => {
        if (res.passed && index + 1 < phases.length) setTimeout(() => setIndex(index + 1), 1500);
      }} />
    </div>
    ${briefing ? html`<${Modal} title=${lesson.title} wide onClose=${() => setBriefing(false)} footer=${html`<${Button} variant="primary" icon=${isBoss ? 'sword' : 'play'} onClick=${() => setBriefing(false)}>${isBoss ? 'Start het gevecht' : 'Start het project'}</${Button}>`}>
      ${lesson.story ? html`<p class="boss-story">${lesson.story}</p>` : null}
      <${Markdown} text=${detail.understand} />
      <h4>Fases</h4>
      <ol>${phases.map((e) => html`<li><strong>${e.phase || e.title}</strong> — ${e.title}</li>`)}</ol>
    </${Modal}>` : null}
  </div>`;
}

/** Een verzameling extra oefeningen (vrij te kiezen). */
function ChallengeSet({ lesson, detail }) {
  const p = useProgress();
  return html`<div class="lesson">
    <${LessonHeader} lesson=${lesson} />
    <div class="lesson-body">
      <${Markdown} text=${detail.understand} />
      <div class="grid grid-auto" style="margin-top:16px">
        ${lesson.exercises.map((e) => html`<a class="card interactive exercise-card" href=${`#/lab/${e.id}`}>
          <div class="row between"><${Badge} tone="xp" icon="zap">${e.xp} XP</${Badge}>${p.exercises[e.id]?.status === 'passed' ? html`<${Badge} tone="success" icon="check">Geslaagd</${Badge}>` : null}</div>
          <h4 style="margin:10px 0 4px">${e.title}</h4>
          <p class="faint xs">${e.source || ''}</p>
        </a>`)}
      </div>
    </div>
  </div>`;
}
