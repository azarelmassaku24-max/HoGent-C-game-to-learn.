import { html } from '../lib/preact.js';
import { Workbench } from '../features/lab/Workbench.js';
import { curriculumService } from '../services/curriculumService.js';
import { LinkButton } from '../components/ui.js';
import { Icon } from '../components/Icon.js';

/** Code Lab: vrije programmeeromgeving, of één specifieke opdracht (#/lab/<id>). Elke opdracht is altijd te openen. */
export function CodeLab({ exerciseId, daily }) {
  const c = curriculumService.get();
  let initial = null;
  if (!exerciseId) {
    try {
      const imported = JSON.parse(sessionStorage.getItem('csq.lab.import') || 'null');
      if (imported) { initial = imported; sessionStorage.removeItem('csq.lab.import'); }
    } catch { /* */ }
  }
  if (exerciseId && !c.exercises.get(exerciseId)) {
    return html`<div class="page"><div class="message-screen card">
      <div class="icon-tile muted" style="width:56px;height:56px"><${Icon} name="alert" size="26" /></div>
      <h2>Opdracht niet gevonden</h2>
      <p class="muted">De opdracht “${exerciseId}” bestaat niet (meer).</p>
      <div class="row" style="justify-content:center">
        <${LinkButton} href="#/lab" icon="code">Naar het vrije Code Lab</${LinkButton}>
        <${LinkButton} href="#/uitdagingen" variant="ghost" icon="target">Naar de oefenpool</${LinkButton}>
      </div>
    </div></div>`;
  }
  return html`<div class="lab-page"><${Workbench} key=${exerciseId || 'free'} exerciseId=${exerciseId || null} daily=${daily} initial=${initial} /></div>`;
}
